﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using AppWSIBC.Models;
using AppWSIBC.Services;

namespace AppWSIBC.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PagePesquisa : ContentPage
    {
        public PagePesquisa()
        {
            InitializeComponent();
        }

        private void slPergunta1_ValueChanged(object sender, ValueChangedEventArgs e)
        {
            txtPergunta1.Text = ((Slider)slPergunta1).Value.ToString("0");
        }

        private void Button_Clicked(object sender, EventArgs e)
        {
            try
            {
                Pesquisa pesquisa = new Pesquisa();
                int Pergunta1 = Convert.ToInt32(txtPergunta1.Text.Trim());
                int Pergunta2 = Convert.ToInt32(txtPergunta2.Text.Trim());
                int Pergunta3 = Convert.ToInt32(txtPergunta3.Text.Trim());
                pesquisa.Pergunta1 = Pergunta1;
                pesquisa.Pergunta2 = Pergunta2;
                pesquisa.Pergunta3 = Pergunta3;
                if (txtNome.Text == "")
                {
                    DisplayAlert("Nome","Digite o seu nome, por favor!", "OK");
                }
                else
                {
                    pesquisa.Nome = txtNome.Text;
                    int soma = pesquisa.Pergunta1 + pesquisa.Pergunta2 + pesquisa.Pergunta3;
                    double resultado = (((Convert.ToDouble(soma) / 3) - 1) / 9) * 100;
                    pesquisa.Resultado = resultado;
                    ServiceBDPesquisa db = new ServiceBDPesquisa(App.DbPath);
                    db.Inserir(pesquisa);
                    Navigation.PushAsync(new PageResultado(pesquisa));
                }
            }
            catch (Exception erro)
            {
                DisplayAlert("Erro", erro.Message, "OK");
            }
        }

        private void slPergunta2_ValueChanged(object sender, ValueChangedEventArgs e)
        {
            txtPergunta2.Text = ((Slider)slPergunta2).Value.ToString("0");
        }

        private void slPergunta3_ValueChanged(object sender, ValueChangedEventArgs e)
        {
            txtPergunta3.Text = ((Slider)slPergunta3).Value.ToString("0");
        }
    }
}