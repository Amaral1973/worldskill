﻿using System;
using System.Collections.Generic;
using System.Text;
using AppWSIBC.Models;
using SQLite;

namespace AppWSIBC.Services
{
    public class ServiceBDPesquisa
    {
        SQLiteConnection conn;

        public string StatusMessage { get; set; }

        public ServiceBDPesquisa(string dbPath)
        {
            if (dbPath == "") dbPath = App.DbPath;
            conn = new SQLiteConnection(dbPath);
            conn.CreateTable<Pesquisa>();
        }

        public void Inserir(Pesquisa pesquisa)
        {
            try
            {
                if (string.IsNullOrEmpty(pesquisa.Nome))
                    throw new Exception("Por favor, insira o seu nome!");
                int result = conn.Insert(pesquisa);
                if (result != 0)
                {
                    this.StatusMessage = string.Format("Pesquisa realizada com sucesso!");
                }
                else
                {
                    this.StatusMessage = string.Format("Pesquisa não foi realizada!");
                }

            }
            catch (Exception erro)
            {
                throw new Exception(erro.Message);
            }
        }
    }
}
