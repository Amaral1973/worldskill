<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <script src="bootstrap/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <title>Controle de Quartos</title>
</head>

<body>
    <center>
        <h2><b>CADASTRO DE PACIENTES / QUARTOS</b></h2>
    </center>
    <hr />
    <br />
    <br />
    <div class="container">
        <div class="row row-cols-2 row-cols-md-4 text-center">
            <div class="col-md-12">
                <div class="card mb-4 rounded-3 shadow-sw">
                    <div class="card-header py-3">
                        <h3><b>PACIENTES / QUARTOS</b></h3>
                        <button type="button" class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#exampleModal">CADASTRAR</button>
                    </div>
                    <div class="card-body">
                        <?php
                        include 'paciente.php';
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Cadastro de Pacientes</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="cadastro.php" method="post">
                        <label>NOME DO PACIENTE</label>
                        <input type="text" class="form-control" name="paciente" required />
                        <br />
                        <label>NOME DO DOUTOR</label>
                        <input type="text" class="form-control" name="doutor" required />
                        <br />
                        <select class="form-select" aria-label="Default select example" name="tipo">
                            <option selected>Selecione um tipo de quarto</option>
                            <option value="Solteiro">SOLTEIRO</option>
                            <option value="Duplo">DUPLO</option>
                            <option value="Triplo">TRIPLO</option>
                        </select>
                        <br/>
                        <label>NÚMERO DO QUARTO</label>
                        <input type="number" class="form-control" name="quarto" required />
                        <br />
                        <button type="submit" class="btn btn-outline-success">CADASTRAR</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>
</body>

</html>