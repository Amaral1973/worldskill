<?php
include 'conecta.php';
$paciente = $_POST["paciente"];
$doutor = $_POST["doutor"];
$tipo = $_POST["tipo"];
$quarto = $_POST["quarto"];

$paciente2 = mysqli_query($conn, "SELECT * FROM paciente WHERE nome_paciente='$paciente'");
$repetido = mysqli_num_rows($paciente2);

if ($repetido > 0) {
    echo "<script language='javascript' type='text/javascript'>
        alert('Este paciente já existe em nossa base de dados!');
        window.location.href='index.php';
        </script>";
    exit;
}


$paciente2 = mysqli_query($conn, "SELECT tipo_quarto,count(quarto) as quantidade FROM paciente WHERE tipo_quarto='$tipo' AND quarto=$quarto");
while ($registro = $paciente2->fetch_array()) {
    $tipo2 = $registro['tipo_quarto'];
    $quantidade = $registro['quantidade'];
}

if ($tipo2 == "Solteiro" && $quantidade == 1) {
    echo "<script language='javascript' type='text/javascript'>
            alert('Este quarto já existe um paciente cadastrado, tente novamente!');
            window.location.href='index.php';
            </script>";
    exit;
} elseif ($tipo2 == "Duplo" && $quantidade == 2) {
    echo "<script language='javascript' type='text/javascript'>
            alert('Este quarto já existe dois pacientes cadastrados, tente novamente!');
            window.location.href='index.php';
            </script>";
    exit;
} elseif ($tipo2 == "Triplo" && $quantidade == 3) {
    echo "<script language='javascript' type='text/javascript'>
    alert('Este quarto já existe três pacientes cadastrados, tente novamente!');
    window.location.href='index.php';
    </script>";
    exit;
} else {
    $sql = "INSERT INTO paciente(nome_paciente,nome_doutor,tipo_quarto,quarto) VALUES ('$paciente','$doutor','$tipo',$quarto)";
    if (mysqli_query($conn, $sql)) {
        echo "<script language='javascript' type='text/javascript'>
                window.location.href='index.php';
                </script>";
    }
}
mysqli_close($conn);
