<?php
    include 'conecta.php';
    $id = $_GET['id'];
    $paciente = $_POST['paciente'];
    $doutor = $_POST['doutor'];
    $tipo = $_POST['tipo'];
    $quarto = $_POST['quarto'];
    $sql = "UPDATE paciente SET nome_paciente=?,nome_doutor=?,tipo_quarto=?,quarto=? WHERE id=?";
    $stmt = $conn->prepare($sql) or die($conn->error);
    if (!$stmt) {
        echo "Erro:".$conn->error;
    }
    $stmt->bind_param('sssii',$paciente,$doutor,$tipo,$quarto,$id);
    $stmt->execute();
    $stmt->close();
    header("Location: index.php");
?>