<?php
include 'conecta.php';
$id = $_GET['id'];
$sql = "SELECT * FROM paciente WHERE id=$id";
$query = $conn->query($sql);
while ($dados = $query->fetch_array()) {
    $paciente = $dados['nome_paciente'];
    $doutor = $dados['nome_doutor'];
    $tipo = $dados['tipo_quarto'];
    $quarto = $dados['quarto'];
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <script src="bootstrap/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <title>Controle de Quartos</title>
</head>

<body>
    <center>
        <h2><b>PACIENTES / QUARTOS</b></h2>
    </center>
    <hr />
    <br />
    <br />
    <div class="container">
        <div class="row row-cols-2 row-cols-md-4 text-center">
            <div class="col-md-12">
                <div class="card mb-4 rounded-3 shadow-sw">
                    <div class="card-header py-3">
                        <h3><b>EDIÇÃO DE PACIENTES</b></h3>
                    </div>
                    <div class="card-body text-start">
                        <form action="edpaciente.php?id=<?php echo $id; ?>" method="post">
                            <label>NOME DO PACIENTE</label>
                            <input type="text" class="form-control" name="paciente" value="<?php echo $paciente; ?>" required />
                            <br />
                            <label>NOME DO DOUTOR</label>
                            <input type="text" class="form-control" name="doutor" value="<?php echo $doutor; ?>" required />
                            <br />
                            <select class="form-select" aria-label="Default select example" name="tipo">
                                <option selected><?php echo $tipo; ?></option>
                                <option value="Solteiro">SOLTEIRO</option>
                                <option value="Duplo">DUPLO</option>
                                <option value="Triplo">TRIPLO</option>
                            </select>
                            <br />
                            <label>NÚMERO DO QUARTO</label>
                            <input type="number" class="form-control" name="quarto"  value="<?php echo $quarto; ?>" required />
                            <br />
                            <button type="submit" class="btn btn-outline-success">ATUALIZAR</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>