<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta http-equiv="content-language" content="pt-br">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>PESQUISA IBC</title>
    <style>
        .header {
            float: right;
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <h2><b>PESQUISA IBC</b></h2>
    <hr />
    <br />
    <div class="row justify-content-center row-cols-1 row-cols-md-2 mb-2 text-center">
        <div class="col">
            <div class="card mb-2 rounded-3 shadow-sw">
                <div class="card-header py-3">
                    <h3 class="my-0 fw-normal"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="green" class="bi bi-calendar2-check" viewBox="0 0 16 16">
                            <path d="M10.854 8.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 0 1 .708-.708L7.5 10.793l2.646-2.647a.5.5 0 0 1 .708 0" />
                            <path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5M2 2a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1z" />
                            <path d="M2.5 4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5H3a.5.5 0 0 1-.5-.5z" />
                    </svg>&nbsp;&nbsp;<b>PESQUISA</b></h3>
                </div>
                <div class="card-body">
                    <form action="resultado.php" method="post">
                        <input type="text" class="form-control" name="nome" placeholder="Digite o seu nome" required/>
                        <br/>
                        <br/>
                        <h5>1 - Qual é seu nível de satisfação com o ambiente de trabalho hoje?</h5>
                        <br/>
                        <table class="table">
                            <tr>
                                <td><input type="radio" name="pergunta1" id="pergunta1" value="1" /></td>
                                <td><input type="radio" name="pergunta1" id="pergunta1" value="2" /></td>
                                <td><input type="radio" name="pergunta1" id="pergunta1" value="3" /></td>
                                <td><input type="radio" name="pergunta1" id="pergunta1" value="4" /></td>
                                <td><input type="radio" name="pergunta1" id="pergunta1" value="5" /></td>
                                <td><input type="radio" name="pergunta1" id="pergunta1" value="6" /></td>
                                <td><input type="radio" name="pergunta1" id="pergunta1" value="7" /></td>
                                <td><input type="radio" name="pergunta1" id="pergunta1" value="8" /></td>
                                <td><input type="radio" name="pergunta1" id="pergunta1" value="9" /></td>
                                <td><input type="radio" name="pergunta1" id="pergunta1" value="10" /></td>
                            </tr>
                            <tr>
                                <td>1</td>
                                <td>2</td>
                                <td>3</td>
                                <td>4</td>
                                <td>5</td>
                                <td>6</td>
                                <td>7</td>
                                <td>8</td>
                                <td>9</td>
                                <td>10</td>
                            </tr>
                        </table>
                        <br/>
                        <h5>2 - Atualmente, o ambiente de trabalho atende às suas expectativas?</h5>
                        <br/>
                        <table class="table">
                            <tr>
                                <td><input type="radio" name="pergunta2" id="pergunta2" value="1" /></td>
                                <td><input type="radio" name="pergunta2" id="pergunta2" value="2" /></td>
                                <td><input type="radio" name="pergunta2" id="pergunta2" value="3" /></td>
                                <td><input type="radio" name="pergunta2" id="pergunta2" value="4" /></td>
                                <td><input type="radio" name="pergunta2" id="pergunta2" value="5" /></td>
                                <td><input type="radio" name="pergunta2" id="pergunta2" value="6" /></td>
                                <td><input type="radio" name="pergunta2" id="pergunta2" value="7" /></td>
                                <td><input type="radio" name="pergunta2" id="pergunta2" value="8" /></td>
                                <td><input type="radio" name="pergunta2" id="pergunta2" value="9" /></td>
                                <td><input type="radio" name="pergunta2" id="pergunta2" value="10" /></td>
                            </tr>
                            <tr>
                                <td>1</td>
                                <td>2</td>
                                <td>3</td>
                                <td>4</td>
                                <td>5</td>
                                <td>6</td>
                                <td>7</td>
                                <td>8</td>
                                <td>9</td>
                                <td>10</td>
                            </tr>
                        </table>
                        <br/>
                        <h5>3 - Quão próximo do ideal está seu atual ambiente de trabalho?</h5>
                        <br/>
                        <table class="table">
                            <tr>
                                <td><input type="radio" name="pergunta3" id="pergunta3" value="1" /></td>
                                <td><input type="radio" name="pergunta3" id="pergunta3" value="2" /></td>
                                <td><input type="radio" name="pergunta3" id="pergunta3" value="3" /></td>
                                <td><input type="radio" name="pergunta3" id="pergunta3" value="4" /></td>
                                <td><input type="radio" name="pergunta3" id="pergunta3" value="5" /></td>
                                <td><input type="radio" name="pergunta3" id="pergunta3" value="6" /></td>
                                <td><input type="radio" name="pergunta3" id="pergunta3" value="7" /></td>
                                <td><input type="radio" name="pergunta3" id="pergunta3" value="8" /></td>
                                <td><input type="radio" name="pergunta3" id="pergunta3" value="9" /></td>
                                <td><input type="radio" name="pergunta3" id="pergunta3" value="10" /></td>
                            </tr>
                            <tr>
                                <td>1</td>
                                <td>2</td>
                                <td>3</td>
                                <td>4</td>
                                <td>5</td>
                                <td>6</td>
                                <td>7</td>
                                <td>8</td>
                                <td>9</td>
                                <td>10</td>
                            </tr>
                        </table>
                        <br/>
                        <button type="submit" class="btn btn-outline-success"><b>RESULTADO</b></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>