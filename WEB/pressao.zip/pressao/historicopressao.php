<?php
    include 'conecta.php';
    $pressao = mysqli_query($conn, "SELECT * FROM pressao");
    $registros = mysqli_num_rows($pressao);
    if ($registros > 0) {
        echo "<table class='table table-hover'>";
        echo "<thead>";
        echo "<tr>";
        echo "<th>ID</th>";
        echo "<th>SISTOLE</th>";
        echo "<th>DIASTOLE</th>";
        echo "<th>DATA</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";
        while ($registro = $pressao->fetch_array()) {
            echo "<tr>";
            echo "<td>".$registro['id']."</td>";
            echo "<td>".$registro['sistole']."</td>";
            echo "<td>".$registro['diastole']."</td>";
            echo "<td>".$registro['data']."</td>";
            echo "</tr>";
        }
        echo "</tbody>";
        echo "</table>";
    }
    else {
        echo "<center><h2><b>NÃO EXISTEM PRESSÕES MEDIDAS!</b></h2></center>";
        echo "</tbody>";
        echo "</table>";
    }
    echo "Total de pressões arteriais medidas: ".$registros;
    echo "<br/>";
    echo "<a href='index.php' class='btn btn-outline-success' role='button' aria-disabled='true'><b>VOLTAR</b></a>";
?>