<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <title>Controle da Pressão</title>
</head>

<body>
    <center>
        <h2><b>PRESSÃO ARTERIAL</b></h2>
    </center>
    <hr />
    <br />
    <br />
    <div class="container">
        <div class="row row-cols-2 row-cols-md-4 text-center">
            <div class="col-md-12">
                <div class="card mb-4 rounded-3 shadow-sw">
                    <div class="card-header py-3">
                        <h3><b>HISTÓRICO DA PRESSÃO</b></h3>
                    </div>
                    <div class="card-body">
                        <?php
                        include 'historicopressao.php';
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>