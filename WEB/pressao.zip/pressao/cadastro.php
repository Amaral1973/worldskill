<?php
include 'conecta.php';
$sistole = $_POST["sistole"];
$diastole = $_POST["diastole"];
$data = date("Y-m-d H:i:s");

$sql = "INSERT INTO pressao(sistole,diastole,data) VALUES ('$sistole','$diastole','$data')";
if (mysqli_query($conn, $sql)) {
    echo "<script language='javascript' type='text/javascript'>
        window.location.href='index.php';
        </script>";
}
mysqli_close($conn);
