<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</head>

<body>
    <center>
        <h4><b>MÉDIA DA PRESSÃO ARTERIAL</b></h4>
        <br/>
        <h4>SISTOLE</h4>
        <?php
            include 'conecta.php';
            $pressao = mysqli_query($conn, "SELECT avg(sistole) as sistole, avg(diastole) as diastole from pressao");
            $registros = mysqli_num_rows($pressao);
            while ($registro = $pressao->fetch_array()) {
                $sistole = $registro['sistole'];
                $diastole = $registro['diastole'];
            }
            $sis = number_format($sistole,2);
            $dis = number_format($diastole,2);
        ?>
        <h1><?php echo $sis; ?></h1>
        <br/>
        <h4>DIASTOLE</h4>
        <h1><?php echo $dis; ?></h1>
        <br/>
    </center>
    <a href="historico.php" class="btn btn-outline-success" tabindex="-1" role="button" aria-disabled="true"><b>VER HISTÓRICO</b></a>
</body>

</html>